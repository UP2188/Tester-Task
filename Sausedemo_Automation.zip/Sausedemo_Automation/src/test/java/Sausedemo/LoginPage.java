package Sausedemo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {
	
	WebDriver driver;
	WebDriverWait wait;
	
	//Constructor
	public LoginPage(WebDriver driver) {
	 
	this.driver=driver;
	this.wait = new WebDriverWait(driver,Duration.ofSeconds(20));
	}

	//Locators
	By username = By.id("user-name");
	By password = By.id("password");
	By loginButton = By.id("login-button");
	By filter = By.xpath("//select[@class='product_sort_container']");
	By selectPrice = By.xpath("//option[@value='hilo'][1]");
	By addtocart = By.id("add-to-cart-sauce-labs-fleece-jacket");
	By viewCart = By.id("shopping_cart_container");
	By checkout = By.xpath("//button[@id='checkout']");
	By firstName = By.id("first-name");
	By lastName = By.id("last-name");
	By postalCode = By.id("postal-code");
	By continueButton = By.id("continue");
	By finish = By.id("finish");
	By messege = By.xpath("//div[@class='error-message-container error']");
	By inventory = By.id("inventory_container");
	By orderConfirmation = By.className("complete-header");
	
	//Action Method username
	public void enterUsername(String user) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(username)).sendKeys(user);
	}
	
	//password
	public void enterPassword(String pass) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(password)).sendKeys(pass);
	}
	
	//Login
	public void clickLogin() {
		wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
	}
	
	//Reusable login method
	public void login(String user, String pass) {
		
		enterUsername(user);
		enterPassword(pass);
		clickLogin();
	}
	
	// Verify successful login
    public boolean isInventoryDisplayed() {
        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(inventory)
        ).isDisplayed();
    }
	
	//Select price High to Low
		public void priceSelected() {
			wait.until(ExpectedConditions.visibilityOfElementLocated(filter));
			
			Select select = new Select(driver.findElement(filter));
			select.selectByValue("hilo");
		}
		
		//AddToCart
		public void productAddtoCart() {
			wait.until(ExpectedConditions.elementToBeClickable(addtocart)).click();
		}
		
		//ViewCart
		public void viewCartDetails() {
			wait.until(ExpectedConditions.elementToBeClickable(viewCart)).click();
		}
		
		//Checkout
		public void productCheckout() {
			wait.until(ExpectedConditions.elementToBeClickable(checkout)).click();
		}
		
		//Customer details
		public void customerName(String name) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).sendKeys(name);
		}
		
		//LastName
		public void customerLastName(String lastN) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(lastName)).sendKeys(lastN);
		}
		
		//PostalCode
		public void code(String pin) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(postalCode)).sendKeys(pin);
		}
		
		// Enter Complete Customer Details
	    public void enterCustomerDetails(String name, String lastN, String pin) {
	        customerName(name);
	        customerLastName(lastN);
	        code(pin);
	    }
		
		//ContinueButton
		public void clickContinue() {
			wait.until(ExpectedConditions.elementToBeClickable(continueButton)).click();
		}
		
		//Finish
		public void finishButton() {
			wait.until(ExpectedConditions.elementToBeClickable(finish)).click();
		}
	
	//Get login massage
	public String getLoginMessage() {
		return wait.until(ExpectedConditions.visibilityOfElementLocated(messege)).getText();
	}
	
	// Get Order Confirmation Message
    public String getOrderConfirmation() {
        return wait.until(
            ExpectedConditions.visibilityOfElementLocated(orderConfirmation)
        ).getText();
    }
}

