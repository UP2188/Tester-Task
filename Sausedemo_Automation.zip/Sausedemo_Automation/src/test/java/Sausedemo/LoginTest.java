package Sausedemo;

import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {
	
	//Test case 1: Valid Login
	@Test(priority = 1)
	public void verifyCompletePurchase()throws Throwable {
		try {
			LoginPage loginpage = new LoginPage(driver);
			
			 // Step 1: Login
            loginpage.login("standard_user", "secret_sauce");

            Assert.assertTrue(
                loginpage.isInventoryDisplayed(),
                "Login Failed"
            );

            System.out.println("Login Successful");

            // Step 2: Sort Price High to Low
            loginpage.priceSelected();

            System.out.println("Product Sorted: High to Low");

            // Step 3: Add Product to Cart
            loginpage.productAddtoCart();

            System.out.println("Product Added to Cart");

            // Step 4: View Cart
            loginpage.viewCartDetails();

            System.out.println("Cart Opened Successfully");

            // Step 5: Checkout
            loginpage.productCheckout();

            System.out.println("Checkout Started");

            // Step 6: Enter Customer Details
            loginpage.enterCustomerDetails(
                "Umesh",
                "Patil",
                "412207"
            );

            System.out.println("Customer Details Entered");

            // Step 7: Continue
            loginpage.clickContinue();

            System.out.println("Checkout Overview Displayed");

            // Step 8: Finish Order
            loginpage.finishButton();

            System.out.println("Order Finished");

            // Step 9: Verify Order Confirmation
            String actualMessage =
                loginpage.getOrderConfirmation();

            Assert.assertEquals(
                actualMessage,
                "Thank you for your order!",
                "Order Confirmation Failed"
            );

            System.out.println(
                "Complete Purchase Test Passed Successfully"
            );

        } catch (Throwable e) {

            captureFailureScreenshot("verifyCompletePurchase");

            throw e;
        }
    }

		
		//Test case 2: Invalid Login
		@Test(priority = 2)
		public void verifyInvalidLogin() {
			
			try {
				LoginPage loginpage = new LoginPage(driver);
				loginpage.login("InvalidUser", "WrongPassword");
				
				String actualMessage = loginpage.getLoginMessage();
				
				System.out.println("Actual Message:" + actualMessage);
				
				Assert.assertTrue(actualMessage.contains("Username and password do not match"),
						                                 "Invalid login test failed");
				
				System.out.println("Invalid Login Test Passed");
				
			}catch(Throwable e) {
				captureFailureScreenshot("verifyInvalidLogin");
				
				throw e;
			}
		}
		
	}
