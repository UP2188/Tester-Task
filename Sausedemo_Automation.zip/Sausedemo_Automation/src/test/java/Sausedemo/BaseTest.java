package Sausedemo;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class BaseTest {
	
	WebDriver driver;
	
	@BeforeMethod
	public void setup() {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.saucedemo.com/");
		System.out.println("Browser Lounched Successfuly");
	}
	
	// Screenshot method
    public void captureFailureScreenshot(String testName) {

        try {

            File source = ((TakesScreenshot) driver)
                    .getScreenshotAs(OutputType.FILE);

            Path destination = Paths.get(
                    "ScreenShot",
                    testName + "_" + System.currentTimeMillis() + ".png"
            );

            Files.createDirectories(destination.getParent());

            Files.copy(source.toPath(), destination);

            System.out.println("Screenshot captured: " + destination);

        } catch (IOException e) {

            e.printStackTrace();
        }
    }

	@AfterMethod
	public void tearDown() {
		if(driver != null) 
		driver.quit();
	}
 }

